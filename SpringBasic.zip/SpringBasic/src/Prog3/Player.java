package Prog3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class Player {
	private String playerId;
	private String playerName;
	private Country country;
	public String getPlayerId() {
		return playerId;
	}
	public void setPlayerId(String playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	@Autowired
	public void setCountry(Country country) {
		this.country = country;
	}
	public Country getCountry() {
		return country;
	}
	
	
}
