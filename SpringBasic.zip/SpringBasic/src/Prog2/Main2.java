package Prog2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("NewSpringFile.xml");
		Student students = null;
		
		List<Student>studentlist=new ArrayList<Student>();
		List<Test> testlist=new ArrayList<Test>();
		System.out.println("--------------------Student Marklist Entry---------------------------");
		 Scanner input=new Scanner(System.in);
		
		 System.out.println("Enter the number of students");
	     int count=input.nextInt();
	     Test test = null;
	    for(int i=0;i<count;i++){
	    	
		students= (Student) context.getBean("StudentBean");
	      
	      System.out.println("Enter the Student Id");
	      students.setStudentId(input.next());
	      System.out.println("Enter the Student name");
	      students.setStudentName(input.next());
	      System.out.println("Number of test and Test Id attended by "+students.getStudentName());
	      int numberOfTest=input.nextInt();
	      testlist = new ArrayList<Test>();
	     
	      for(int i1=0;i1<numberOfTest;i1++)
	      {
	    	  System.out.println("Test Id:");
	    	  String testid=input.next();
	    	  System.out.println("Enter the mark of "+testid);
	    	  if(testid.equals("T001"))
	    		  test=(Test)context.getBean("test");
	    		 
	    	  if(testid.equals("T002"))
	    		  test=(Test)context.getBean("test1");
	    	  
	    		  test.setTestMarks(input.nextInt());
	    		  testlist.add(test);
	     }
	     
	      students.setStudentTest(testlist);
	      studentlist.add(students);
	    }
	      System.out.println("------------------------------Marklist------------------------------");
	      System.out.println("STUDENT_ID\tSTUDENT_NAME\tTEST_ID\tTEST_TITLE\tMARK_OBTAINED");
	      System.out.println("--------------------------------------------------------------------");
	      Iterator<Student> i=studentlist.iterator();
	      while(i.hasNext()){
	    	  Student s=i.next();
	      System.out.print(s.getStudentId()+"\t\t");
	      System.out.println(s.getStudentName());
	      
	      testlist=s.getStudentTest();
	      Iterator<Test> tst=testlist.iterator();
		      while(tst.hasNext()){
		    	  Test t = tst.next();
		    	  System.out.println("\t\t\t\t"+t.getTestId()+"\t"+t.getTestTitle()+"\t"+t.getTestMarks());
	 	     
		      }
		      System.out.println("--------------------------------------------------------------------");
	      }
	}

}
