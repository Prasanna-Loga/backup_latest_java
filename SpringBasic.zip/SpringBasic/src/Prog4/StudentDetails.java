package Prog4;

import java.util.List;

public class StudentDetails {
	private List<Student> studentDetail;

	public List<Student> getStudentDetail() {
		return studentDetail;
	}

	public void setStudentDetail(List<Student> studentDetail) {
		this.studentDetail = studentDetail;
	}
	
	public void getDetails(String studentId){
		
	}
}
