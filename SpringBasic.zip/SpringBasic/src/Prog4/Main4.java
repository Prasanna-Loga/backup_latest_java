package Prog4;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Main4 {
	static List<Student>studentlist=new ArrayList<Student>();
	static ApplicationContext ctx = new ClassPathXmlApplicationContext("NewSpringFile.xml");
	
	
public void getAllDetails(){
	try {
		Thread.sleep(100000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	StudentDetails detail = (StudentDetails) ctx.getBean("StuDetailBean");
	studentlist=detail.getStudentDetail();
	Iterator i=studentlist.iterator();
	while(i.hasNext()){
		Student student=(Student) i.next();
		System.out.print(student.getStudentId()+"\t\t"+student.getStudentName());
		System.out.println("\t\t"+student.getStudentAddress());
	}
	}
public void getDetails(String studentId){
	
	StudentDetails detail = (StudentDetails) ctx.getBean("StuDetailBean");
	studentlist=detail.getStudentDetail();
	Iterator i=studentlist.iterator();
	while(i.hasNext()){
		Student student=(Student) i.next();
		if(student.getStudentId().equalsIgnoreCase(studentId)){
			System.out.println("STUDENT_ID\tSTUDENT_NAME\tADDRESS");
		System.out.print(student.getStudentId()+"\t\t"+student.getStudentName());
	System.out.println("\t\t"+student.getStudentAddress());
		}
	}
	}
	
	public static void main(String[] args){
		Student student = null;
		StudentDetails detail = (StudentDetails) ctx.getBean("StuDetailBean");
		Main4 mainMethod = (Main4)ctx.getBean("main4");
		System.out.println("----------------Student Details Entry-----------------------");
		Scanner input = new Scanner(System.in);
		Scanner input1 = new Scanner(System.in);
		System.out.println("Enter the number of Students");
		int count = input.nextInt();
		for (int i = 0; i < count; i++) {
			student = (Student) ctx.getBean("StuBean");
		System.out.println("Enter the name of the student:");
		student.setStudentName(input.next());
		System.out.println("Enter the student id:");
		student.setStudentId(input.next());
		System.out.println("Enter the address of the student");
		student.setStudentAddress(input1.nextLine());
		studentlist.add(student);
		detail.setStudentDetail(studentlist);
		}
		System.out.println("------------------------------Student Detail list------------------------------");
		System.out.println("STUDENT_ID\tSTUDENT_NAME\tADDRESS");
		System.out.println("--------------------------------------------------------------------");
		mainMethod.getAllDetails();
		System.out.println("Enter the Student Id");
		mainMethod.getDetails(input.next());
	}
}
