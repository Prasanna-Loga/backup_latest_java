package Prog1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Prog1.Movie;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("NewSpringFile.xml");
	      
	      Movie obj = (Movie) context.getBean("MovieBean");
	      System.out.println("Details of the movie");
	      System.out.println("Movie ID : "+obj.getMovieId());
	      System.out.println("Movie Name : "+obj.getMovieName());
	      System.out.println("Movie Actor :"+obj.getMovieActor());
	}

}
