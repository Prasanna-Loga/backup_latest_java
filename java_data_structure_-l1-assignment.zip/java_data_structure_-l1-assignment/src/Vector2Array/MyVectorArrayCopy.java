/*
 * Task to copy elements from Vector to an Array :
 */

package Vector2Array;

import java.util.Enumeration;
import java.util.Vector;

public class MyVectorArrayCopy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> vct = new Vector<String>();
		vct.add("First");
		vct.add("Second");
		vct.add("Third");
		vct.add("Random");
		System.out.println("Actual vector:"+vct);
		int i=0;
		String[] Array=new String[vct.size()];
		Enumeration<String> e=vct.elements();
		while(e.hasMoreElements())
			Array[i++]=(String) e.nextElement();
		System.out.println("Copied Array :");
		for(String j:Array)
			System.out.println(j);
	}

}
