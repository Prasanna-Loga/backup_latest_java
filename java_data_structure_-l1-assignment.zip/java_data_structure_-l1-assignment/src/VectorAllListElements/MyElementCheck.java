/*
 * Task to learn LinkedList push(), pop() operations:
 */

package VectorAllListElements;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;

public class MyElementCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> v=new Vector<String>();
		v.add("First");
		v.add("Second");
		v.add("Third");
		v.add("Random");
		Enumeration<String> e=v.elements();
		System.out.println("Elements in the vector :");
		while(e.hasMoreElements())
		System.out.println(e.nextElement());
		List<String> list=new ArrayList<String>();
		list.add("First");
		list.add("Random");
		System.out.println("Checking for Elements �First�,�Random� in the vector : \t"+v.containsAll(list));
		list=new ArrayList<String>();
		list.add("One");
		list.add("Random");
		System.out.println("Checking for Elements �One�,�Random� in the vector : \t"+v.containsAll(list));
	}

}
