/*
 * 6.	Write  a  program  to  assign  the  current  thread  to  t1.  Change  the  name  of  the  thread  to  MyThread.  
 * Display  the  changed  name  of  the  thread.  Also  it  should  display  the  current  time. 
 *  Put  the  thread  to  sleep  for  10  seconds  and  display  the  time  again
 */

package Prog6_Thread;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Threading {
	@SuppressWarnings("static-access")
	public static void main(String[] args){
		Thread t1=new Thread();
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/YY HH:mm:ss");
		String date = sdf.format(new Date());
		System.out.println("Name of the thread : "+t1.getName());
		t1.setName("MyThread");
		System.out.println("Changed name of the thread : "+t1.getName());
		System.out.println("Current time of the thread : "+date);
		try {
			t1.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		date=sdf.format(new Date());
		System.out.println("Current time of the thread after sleep: "+date);
	}
}
