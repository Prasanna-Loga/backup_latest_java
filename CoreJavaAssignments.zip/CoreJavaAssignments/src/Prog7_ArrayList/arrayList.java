/*
 * 7.	Create an ArrayList of Employee( id,name,address,sal) objects and 
 * search for particular Employee object based on id number and name.
 */

package Prog7_ArrayList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
public class arrayList {
	@SuppressWarnings("resource")
	public static void main(String[] args){
	Emp e=new Emp();
	ArrayList<Emp> empList=new ArrayList<Emp>();
	e.setId("S001");
	e.setName("employee1");
	e.setAddress("address1");
	e.setSalary(20000);
	empList.add(e);
	e=new Emp();
	e.setId("S002");
	e.setName("employee2");
	e.setAddress("address2");
	e.setSalary(25000);
	empList.add(e);
	e=new Emp();
	e.setId("S003");
	e.setName("employee3");
	e.setAddress("address3");
	e.setSalary(30000);
	empList.add(e);
	e=new Emp();
	e.setId("S004");
	e.setName("employee4");
	e.setAddress("address4");
	e.setSalary(35000);
	empList.add(e);
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the id to check : ");
	String id=sc.next();int count=0;
	Iterator<Emp> i=empList.iterator();
	while(i.hasNext()){
		e=(Emp)i.next();
		if(e.getId().equalsIgnoreCase(id)){count=1;
			System.out.println("Id found in the list");
			System.out.println("Id : "+e.getId());
			System.out.println("Name : "+e.getName());
			System.out.println("Address : "+e.getAddress());
			System.out.println("Salary : "+e.getSalary());
		}
	}
	if(count==0)
			System.out.println("Id not found in the list");
	System.out.println("Enter the Name to check : ");
	String name=sc.next();
	i=empList.iterator();count=0;
	while(i.hasNext()){
		e=(Emp)i.next();
		if(e.getName().equalsIgnoreCase(name)){count=1;
			System.out.println("Name found in the list");
			System.out.println("Id : "+e.getId());
			System.out.println("Name : "+e.getName());
			System.out.println("Address : "+e.getAddress());
			System.out.println("Salary : "+e.getSalary());
		}
	}
		if(count==0)
			System.out.println("Name not found in the list");
	}
}
