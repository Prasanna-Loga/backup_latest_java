package Prog4_Interface.music.wind;

import Prog4_Interface.music.Playable;

public class Saxophone implements Playable{

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing Saxophone");
	}

}
