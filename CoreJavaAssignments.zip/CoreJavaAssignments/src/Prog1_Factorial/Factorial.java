/*1.	Write a program to print factorial of N ( without using any loop)*/

package Prog1_Factorial;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int N=6;
		System.out.println(new Factorial().Fact(N));
	}
	public int Fact(int a){
		if(a==1)
		return a;
		else
			return a*Fact(--a);
		
	}

}
