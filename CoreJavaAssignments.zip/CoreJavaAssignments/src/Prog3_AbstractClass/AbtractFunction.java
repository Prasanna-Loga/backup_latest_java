/*3.	Create an abstract class Instrument which is having the abstract function play.  
 * Create three more sub classes from Instrument which is Piano, Flute, Guitar. 
 * Override the play method inside all three classes printing a message 
             �Piano is playing  tan tan tan tan  �  for Piano class
              �Flute is playing  toot toot toot toot�  for Flute class
              �Guitar is playing  tin  tin  tin �  for Guitar class 
      Create an array of 10 Instruments.
      Assign different type of instrument to Instrument reference.
     Check for the polymorphic behavior of  play method.

*/

package Prog3_AbstractClass;
abstract class Instrument{
	abstract void play();
} 
class Piano extends Instrument{
	void play() {
		System.out.println("Piano is playing  tan tan tan tan");	
	}	
}
class Flute extends Instrument{

	@Override
	void play() {
		System.out.println("Flute is playing  toot toot toot toot");	
	}
}
class Guitar extends Instrument{

	@Override
	void play() {
		System.out.println("Guitar is playing  tin  tin  tin ");	
	}
}
public class AbtractFunction {
	public static void main(String[] args){
		/*Instrument i=new Piano();
		i.play();
		i=new Flute();
		i.play();
		i=new Guitar();
		i.play();*/
		Instrument[] a = new Instrument[10];
	
		for(int j=0;j<10;j++){
			if(j%3==1){
			a[j]=new Piano();a[j].play();}
		if(j%3==2){
			a[j]=new Flute();a[j].play();}
		if(j%3==0){
			a[j]=new Guitar();a[j].play();}
		}
	}
}
