/*2.	Create java application that open a text file so that you can read the file one line at a time. 
 * Read each line as a String and place that String object into a Linked List.  
 * Print all of the lines in the Linked List in reverse order. 
 * Force all the lines in the Linked List to uppercase and send the results to System. Out*/
package com.b.textfileimport;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class fileImport {

	public Iterator<String> returnReverse(File file){
		
		Iterator<String> lineList=null;
		try {
			List<String> line = Files.readAllLines(Paths.get(file.getPath()),Charset.defaultCharset());
			lineList=line.stream().map(String::toUpperCase).collect(Collectors.toCollection(LinkedList::new)).descendingIterator();	
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return lineList;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file=new File("C:\\Users\\PR377171\\workspace1\\StreamsAssignments\\test1.txt");
		System.out.println("--------------------------Reverse of the given text file---------------------------");
		new fileImport().returnReverse(file).forEachRemaining(System.out::println);
	}

}
