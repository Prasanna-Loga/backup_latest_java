package com.f.bankrecord;

import java.util.Date;

public class Customer {
	private long customerID;
	private String customerName; 
	private String customerAddress;
	private int customerAge;
	private Date customerDate;
	public long getCustomerID() {
		return customerID;
	}
	public void setCustomerID(long customerID) {
		this.customerID = customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public int getCustomerAge() {
		return customerAge;
	}
	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}
	public Date getCustomerDate() {
		return customerDate;
	}
	public void setCustomerDate(Date customerDate) {
		this.customerDate = customerDate;
	}

}
