/*
 * 3.	Write a Java application to find the longest word in a text file.
 */
package com.c.longestword;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.b.textfileimport.fileImport;

public class longestWord {

	public longestWord(File file){
		Optional<String> longestName = null;
		try(BufferedReader ls = Files.newBufferedReader(Paths.get(file.getPath()),Charset.defaultCharset())) {
			
			longestName=ls.lines().flatMap(line->Arrays.stream(line.split("\\s+"))).max(Comparator.comparingInt(String::length));
			System.out.println(longestName.get());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file=new File("C:\\Users\\PR377171\\workspace1\\StreamsAssignments\\test1.txt");
		System.out.println("--------------------------Longest word of the given text file---------------------------");
		new longestWord(file);
	}


}
