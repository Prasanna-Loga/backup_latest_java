package com.e.serialize;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

class SerializeMyClassToBePersisted {

	public MyClassToBePersisted Serialize() {

		MyClassToBePersisted serializeClass = new MyClassToBePersisted("student1", 15, "playing",new School("School_name", 1990));
		return serializeClass;
	}
}

class DeserializeMyClassToBePersisted {

	public MyClassToBePersisted Deserialize(String fileName) {
		MyClassToBePersisted object1 = null;
		try {
			FileInputStream file = new FileInputStream(fileName);
			ObjectInputStream in = new ObjectInputStream(file);

			object1 = (MyClassToBePersisted) in.readObject();

			 in.close();
			 file.close();
		}

		catch (IOException ex) {
			System.out.println("IOException is caught");
		}

		catch (ClassNotFoundException ex) {
			System.out.println("ClassNotFoundException is caught");
		}

		return object1;
	}
}

public class Test {
	public static void main(String[] args) {
		MyClassToBePersisted serializeClass = new SerializeMyClassToBePersisted().Serialize();

		try {

			FileOutputStream file = new FileOutputStream("serialized_file.txt");
			ObjectOutputStream out = new ObjectOutputStream(file);

			out.writeObject(serializeClass);

			out.close();
			file.close();

			System.out.println("Object has been serialized");
		}

		catch (IOException ex) {
			System.out.println("IOException is caught");
		}

		MyClassToBePersisted object1 = new DeserializeMyClassToBePersisted().Deserialize("serialized_file.txt");

		System.out.println("Object has been deserialized ");
		System.out.println("name = " + object1.name);
		System.out.println("age = " + object1.age);
		System.out.println("hobby = " + object1.hobby);
		System.out.println("school name = " + object1.field.nameOfSchool);
		System.out.println("school date = " + object1.field.yearStarted);

	}
}