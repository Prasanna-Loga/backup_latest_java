package com.e.serialize;

import java.io.Serializable;

public class MyClassToBePersisted implements Serializable{

	public String name ; 
	public int age ;
	public String hobby ;
	public School field;
	public MyClassToBePersisted(String name, int age, String hobby, School field) {
		this.name = name;
		this.age = age;
		this.hobby = hobby;
		this.field = field;
	}
		
}
