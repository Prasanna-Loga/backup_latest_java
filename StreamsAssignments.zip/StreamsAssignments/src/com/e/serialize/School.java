package com.e.serialize;

import java.io.Serializable;

public class School implements Serializable{

	public String nameOfSchool;
	public transient int yearStarted ;
	public School(String nameOfSchool, int yearStarted) {
	
		this.nameOfSchool = nameOfSchool;
		this.yearStarted = yearStarted;
	}
	
	
}
