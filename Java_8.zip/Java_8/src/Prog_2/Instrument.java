/*
 *2.	Create two interfaces Piano & Guitar with single default method void play() with different implementations. 
Add single implementation class Instrument for both the interfaces. 
 *Solve method name ambiguity in Instrument class by using two different approaches 
 */

package Prog_2;

public class Instrument implements Guitar{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Instrument().play();
		new piano(){}.play();	
		
	}

	@Override
	public void play() {
		// TODO Auto-generated method stub
		Guitar.super.play();
	}

	

	

}
