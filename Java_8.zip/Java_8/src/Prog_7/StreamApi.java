/*
 * 7.	Create a java class to 
i.	Create a list of string objects
ii.	Count no.strings whose length  is> 5
iii.	Count no.of empty strings
iv.	Find out empty strings & store them into new list by using Stream API.

 */

package Prog_7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamApi {
	public static void main(String[] args){
		
		List<String> list=Arrays.asList("","Tendulkar", "", "kohli", "Dhoni","", "Sehwag","");
		long count=0;
		System.out.println("List is "+list);
		
		count=list.stream().filter(string->string.length()>5).count();
		System.out.println("Count of string with length more than 5 is "+count);
		
		count=list.stream().filter(string->string.isEmpty()).count();
		System.out.println("Count of Empty string is "+count);
		
		List<String> emptyList=new ArrayList<String>();
		emptyList=list.stream().filter(string->string.isEmpty()).collect(Collectors.toList());
		System.out.println("Empty list is "+emptyList);
	}

}
