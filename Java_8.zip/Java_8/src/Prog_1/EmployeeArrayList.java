/*
 * 1.	Create an ArrayList of Employee( id,name,address,sal) objects and 
 * retrieve objects from ArrayList by using forEach() method of Iterable interface.
 */

package Prog_1;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Employee> empList=new ArrayList<Employee>();
		for(int i=0;i<5;i++){
			Employee emp=new Employee();
			emp.setID("iD"+i);
			emp.setName("Employee"+i);
			emp.setAddress("Address"+i);
			emp.setSalary(10000*(i+1));
			empList.add(emp);
		}
		System.out.println("-----------Employee List----------------");
		System.out.println("Employee_ID\tEmployee_Name\tEmployee_Address\tSalary");
		empList.forEach(list->System.out.println(list.getID()+"\t\t"+list.getName()+"\t"+list.getAddress()+"\t\t"+list.getSalary()));
	
		List<String> list=new ArrayList<String>();
		empList.forEach(list1->list.add(list1.getName()));
		System.out.println(list);
		System.out.println(list.stream().collect(Collectors.joining(",")));
	}

}
