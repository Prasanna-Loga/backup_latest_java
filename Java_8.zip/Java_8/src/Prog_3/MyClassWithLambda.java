/*
 * 3.	Create an interface WordCount with single abstract method int count(String str) to count no.of words in a given string.
 *  Implement count(String str) method by using Lambda expression in an implementation class MyClassWithLambda & 
 *  invoke it to display the result on the console. objects based on salaries.
 * 
 */

package Prog_3;

public class MyClassWithLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WordCount count= (String str)->{
			String[] a=str.split(" ");
			return a.length;
		};
		System.out.println(count.Count("Hi, How are you")+" words are present in the given string");
	}


}
